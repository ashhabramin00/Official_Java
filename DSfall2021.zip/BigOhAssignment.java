import java.util.LinkedList;

public class BigOhAssignment 
{

	private static void main(String[] args)
	{
		LinkedList<String> Cat = new LinkedList<String>();
		
		//Create the body parts for the cat as Strings
		private String[] parts = {"tail", "legs", "head", "body"};
		
		Cat.add(paw);
		
	}

}
