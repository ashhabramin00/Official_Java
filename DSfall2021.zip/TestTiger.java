
public class TestTiger 
{
	public static void main(String[] args)
	{
		Tiger.getInstance().roar();
	}

}
