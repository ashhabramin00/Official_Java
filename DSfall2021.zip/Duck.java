
public class Duck {
	public void LayEgg() {
		System.out.println("Smash Egg");
	}

}
