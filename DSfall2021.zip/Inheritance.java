
public interface Inheritance {
	
	public void setName(String firstName, String lastName);
	
	public String getName();
	
	public void setFirst(String firstName);
	
	public String getFirst();
	
	public void setLast(String lastName);
	
	
}
