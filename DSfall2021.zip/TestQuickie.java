
public class TestQuickie 
{
	public static void main(String[] args)
	{
		Quickie Stang = new Quickie();
		
		System.out.println(Quickie.GPS());
	}

}
