import java.util.ArrayList;

public class Stunt 
{
	public static void main(String[] args)
	{
		ArrayList<String> blast = new ArrayList<String>();
		blast.add("Kanye West");
		blast.add("Fivio");
		blast.add("Playboi Carti");
		
		System.out.println("We don't need Carti, he a liar");
		System.out.println()
		
		
	}
}
