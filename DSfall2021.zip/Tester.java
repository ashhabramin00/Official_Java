import java.util.ArrayList;

public class Tester {
	
	//Create an arraylist for the names
	ArrayList<String> names = new ArrayList<>();
	
	//Give them a name
	names.add("Al")
	names.add("Bob")
	names.add("Kanye West")
	
	System.out.println(names);
	System.out.println(names.size);
	
	//replace 
	//replace... again
	System.out.println(names.remove(2));
	

}
