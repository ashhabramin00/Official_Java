import java.util.ArrayList;

public class Iterator 
{
	public void moveThroughElement() {
		ArrayList<String> list = new ArrayList<>();
		for(String singleString : list)
		{
			System.out.println(singleString);
		}
	}

}
