
public class BigOExperiment {
	void nFacRuntimeFunc(int n)
	{
		//Try o(n!)
		for(int i=0; i<n; i++)
		{
			nFacRuntimeFunc(n-1);
		}
		for(int i=0; i<5)
	}

}
