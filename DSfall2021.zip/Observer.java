import java.util.ArrayList;
import java.util
import java.nio.channels.Channel;

public class Observer {
	private String sales;
	private ArrayList<String> customer = new ArrayList<>();
	
	public void registerObserver(Channel channel)
	{
		this.channels.add(channel);
	}
	public void unregisterObserver (Channel channel)
	{
		this.channels.remove(channel);
	}
	public void setNews(Strinf new)
	{
		this.news = news;
		for 
	}
}
