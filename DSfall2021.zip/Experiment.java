import java.util.*;

public class Experiment 
{
	public static void main(String[] args)
	{
		LinkedList<Integer> Linkloop = new LinkedList<>();
		ArrayList<Integer> Smallloop = new ArrayList<>();
		
		// Create tow lists, one LinkedList, one ArrayList
		
		Linkloop.add(1);
		Linkloop.add(1, 10000);
		
		Arrayloop.add(1);
		Arraylinked Loop.add(1, 10000);
		
		System.out.println("Check if LinkedList is empty:" bigLoop); 
		System.out.println(smallLoop);
		
		
	}

}
