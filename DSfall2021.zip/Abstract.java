
public abstract class STUFF
{
	
	// can not construct
	//can carry global variables
	//can carry filled methods 
	//can have abstract methods
	
	//purpose is to allow carrying data and filled methods, but not allow
	//construction of class, in other words, you want to imply that it's the developers
	//job to fill out subclasses.
}
