
public class Generic {

}
